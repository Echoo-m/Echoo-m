# Copyright (c) 2020, Frappe Technologies Pvt. Ltd. and Contributors
# See license.txt

# import frappe
import unittest


class TestBankClearance(unittest.TestCase):
	pass
